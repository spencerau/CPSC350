README

Spencer Au
ID: 002385256
spau@chapman.edu

Partner:
Ben Fellows
bfellows@chapman.edu

CPSC 350 - Section 2
PA5

Source Files:
ListNode.h
DblList.h
TreeNode.h
ScapegoatST.h
Student.h and .cpp
Faculty.h and .cpp
Interface.h and .cpp
main.cpp

References:
https://www.learncpp.com/
https://cplusplus.com/
https://en.cppreference.com/w/
https://www.geeksforgeeks.org/

https://lldb.llvm.org/use/map.html

https://www.geeksforgeeks.org/templates-cpp/
https://www.geeksforgeeks.org/operator-overloading-c/
https://www.geeksforgeeks.org/binary-search-tree-set-1-search-and-insertion/
https://www.geeksforgeeks.org/scapegoat-tree-set-1-introduction-insertion/
https://stackoverflow.com/questions/40421577/has-no-member-named-bst
https://stackoverflow.com/questions/5685471/error-jump-to-case-label-in-switch-statement


People:
Ammar Askar


Instructions:
To Compile: g++ *.cpp -o "Program Name"
To Run: ./"Program Name" 